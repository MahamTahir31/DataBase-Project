<style>
    body{
            background: url("assets/places-bg.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }
    .success-message {
        color: green;
        font-size: 28px;
        text-align: center;
        margin-top: 20px;
        font-weight: bolder;
    }

    .login-link {
        width: 100%;
        
        padding: 10px;
        border: none;
        background-color: #212446;
        color: #fff;
        font-size: 20px;
        cursor: pointer;
        transition: 0.3s all ease-in-out;
       
    }

    .login-link a {
        text-decoration: none;
        
        text-align: center;
    }

    .login-link a:hover {

        font-size: 22px;
        border-radius: 10px;
    }
</style>

<?php
include('./inc/config.php');
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "INSERT INTO users (username,email,password) VALUES (?,?,?)";
if ($stmt = mysqli_prepare($link, $sql)) {
    // Bind variables to the prepared statement as parameters
    mysqli_stmt_bind_param($stmt, "sss", $param_name, $param_email, $param_password);
    //Set parameters
    $param_name = $name;
    $param_email = $email;
    $param_password = $password;
    //Attempt to execute the prepared statement
    if (mysqli_stmt_execute($stmt)) {
        echo '<p class="success-message">Congratulations! Your Account has been created!</p>';
        echo '<button class= login-link ><a href="./login.php" class="login-link">Click here to login</a></button>';
    }
}
