<?php
require_once('fpdf.php');
class TicketPDF extends FPDF
{
     function Header()
    {
        // Set font and font size for the header
        $this->SetFont('Arial', 'B', 14);

        // Add header content
        $this->Cell(0, 10, 'TravelTheWorld', 0, 1, 'C');
        $this->Ln(5);
    }

    function Footer()
    {
        // Set font and font size for the footer
        $this->SetFont('Arial', '', 10);

        // Add footer content
        $this->SetY(-15);
        $this->Cell(0, 10, 'Warning: Do not share your ticket with anyone!', 0, 0, 'C');
    }


    function generateTicket($bookingData)
{
    // Set font and other configurations
    $this->SetFont('Arial', 'B', 12);
    $this->SetMargins(10, 10, 10);
    $this->AddPage();

    // Add content to the PDF
    $this->SetFillColor(230, 230, 230); // Light gray background color
    $this->Cell(0, 15, 'Ticket Information', 0, 1, 'C', true); // Increased height and added background color
    $this->Ln(10);

    $this->SetFont('Arial', 'B', 14); // Bold font, size 14 for section titles
    $this->SetTextColor(0, 0, 255); // Blue text color

    // Add section titles
    $this->Cell(0, 10, 'User Information', 0, 1);
    $this->Ln(5);

    $this->SetFont('Arial', '', 12); // Regular font, size 12 for content
    $this->SetTextColor(0); // Reset text color to black

    // Add user information
    $this->Cell(0, 10, 'Username: ' . $bookingData['username'], 0, 1);
    $this->Cell(0, 10, 'Card Name: ' . $bookingData['card_name'], 0, 1);

    $this->Ln(10);
    $this->SetFont('Arial', 'B', 14); // Bold font, size 14 for section titles
    $this->SetTextColor(255, 0, 0); // Red text color

    // Add section titles
    $this->Cell(0, 10, 'Travel Details', 0, 1);
    $this->Ln(5);

    $this->SetFont('Arial', '', 12); // Regular font, size 12 for content
    $this->SetTextColor(0); // Reset text color to black

    // Add travel details
    $this->Cell(0, 10, 'Stay Duration: ' . $bookingData['stay_duration'], 0, 1);
    $this->Cell(0, 10, 'Travel Date: ' . $bookingData['travel_date'], 0, 1);

    $this->Ln(10);
    $this->SetFont('Arial', 'B', 14); // Bold font, size 14 for section titles
    $this->SetTextColor(0, 128, 0); // Green text color

    // Add section titles
    $this->Cell(0, 10, 'Ticket Details', 0, 1);
    $this->Ln(5);

    $this->SetFont('Arial', '', 12); // Regular font, size 12 for content
    $this->SetTextColor(0); // Reset text color to black

    // Add ticket details
    $this->Cell(0, 10, 'Ticket Count: ' . $bookingData['ticket_count'], 0, 1);
    $this->Cell(0, 10, 'Ticket Price: ' . $bookingData['ticket_price'], 0, 1);
}

}
?>