<style>
    body{
            background: url("assets/places-bg.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }
    .download-button {
        display: inline-block;
        padding: 10px 20px;
        background-color: #181d3c;
        color: white;
        text-decoration: none;
        border-radius: 5px;
    }

    .download-button:hover {
        background-color: #90a491;
    }
</style>


<?php
// Include the database configuration file
include('./inc/config.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $cardName = $_POST['cardName'];
    $stayDuration = $_POST['stayDuration'];
    $travelDate = $_POST['travelDate'];
    $ticketCount = $_POST['ticketCount'];
    $email = $_POST['email'];

    // Retrieve the user's username from the users table
    $userQuery = "SELECT username FROM users WHERE email = '$email'";
    $userResult = $link->query($userQuery);
    if ($userResult->num_rows > 0) {
        $userData = $userResult->fetch_assoc();
        $username = $userData['username'];
    }

    // Prepare and execute the SQL query to insert the booking details into the booking table
    $ticketPrice = calculateTicketPrice($stayDuration, $ticketCount);
    $insertQuery = "INSERT INTO booking (card_name, stay_duration, travel_date, ticket_count, ticket_price, username) 
                    VALUES ('$cardName', '$stayDuration', '$travelDate', '$ticketCount', '$ticketPrice', '$username')";
    if ($link->query($insertQuery) === true) {
        // Booking successful
        $bookingQuery = "SELECT * FROM booking WHERE username = '$username' ORDER BY id DESC LIMIT 1";
        $bookingResult = $link->query($bookingQuery);
        if ($bookingResult->num_rows > 0) {
            $bookingData = $bookingResult->fetch_assoc();

            echo '<div style="border: 1px solid #ccc; padding: 10px; background-color: #f9f9f9; margin-bottom: 20px;">';
            echo '<h3>Your booking has been successfully done.</h3>';
            echo '<p><strong>Username:</strong> ' . $bookingData['username'] . '</p>';
            echo '<p><strong>Card Name:</strong> ' . $bookingData['card_name'] . '</p>';
            echo '<p><strong>Stay Duration:</strong> ' . $bookingData['stay_duration'] . '</p>';
            echo '<p><strong>Travel Date:</strong> ' . $bookingData['travel_date'] . '</p>';
            echo '<p><strong>Ticket Count:</strong> ' . $bookingData['ticket_count'] . '</p>';
            echo '<p><strong>Ticket Price:</strong> ' . $bookingData['ticket_price'] . '</p>';

            // Generate download link for the PDF ticket
            $ticketDownloadLink = 'ticket.php?id=' . $bookingData['id'];
            echo '<a href="' . $ticketDownloadLink . '" class="download-button">Download Ticket</a>';

            echo '</div>';
        } else {
            echo "Error: Unable to retrieve booking details.";
        }
    } else {
        // Booking failed
        echo "Error: " . $insertQuery . "<br>" . $link->error;
    }
}

// Function to calculate the ticket price based on stay duration and ticket count
function calculateTicketPrice($stayDuration, $ticketCount)
{
    $pricePerDay = 20; // Price per day (adjust as needed)
    $ticketPrice = $stayDuration * $ticketCount * $pricePerDay;
    return $ticketPrice;
}
