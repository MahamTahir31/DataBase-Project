<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
     <link rel="stylesheet" href="contactstyle.css">
    <title>ContactUs</title>
</head>
<body>

    <!-- Responsive Contact Page with Dark Mode and Form Validation (vanilla JS).

*Designed & built for desktop and tablets with viewport width >= 720px and in landscape orientation.  -->

<div class="contact-container">
    <div class="left-col">
      <h3 class="logo"> TravelTheWorld</h3>
    </div>
    <div class="right-col">
      <div class="theme-switch-wrapper">
      <label class="theme-switch" for="checkbox">
          <input type="checkbox" id="checkbox" />
          <div class="slider round"></div>
    </label>
    <div class="description">Dark Mode</div>
  </div>
      
      <h1>Contact us</h1>
      <p>Planning to visit Indonesia soon? Get insider tips on where to go, things to do and find best deals for your next adventure.</p>
      
      <form id="contact-form" action="./server.php" method="post">
        <label for="name">Full name</label>
    <input type="text" id="name" name="name" placeholder="Your Full Name" required>
        <label for="email">Email Address</label>
    <input type="email" id="email" name="email" placeholder="Your Email Address" required>
        <label for="message">Message</label>
    <textarea rows="6" placeholder="Your Message" id="message" name="message" required></textarea>
        <!--<a href="javascript:void(0)">--><button type="submit" id="submit" name="submit">Send</button><!--</a>-->
    
  </form>
    <div id="error"></div>
    <div id="success-msg"></div>
    </div>
  </div>
  
  <!-- Image credit: Oliver Sjöström https://www.pexels.com/photo/body-of-water-near-green-mountain-931018/  -->
  <!--<script src="contactjs.js"></script>-->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>