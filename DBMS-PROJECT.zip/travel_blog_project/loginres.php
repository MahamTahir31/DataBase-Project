<?php
session_start(); // Start the session

include('./inc/config.php');

if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM `users` WHERE email = '$email' and password = '$password'";
    $result = $link->query($sql);

    if ($result->num_rows > 0) {
        // Login successful
        $_SESSION['email'] = $email;
        header('Location: index.php');
        exit(); // Make sure to exit after the redirect
    } else {
        echo 'Wrong email/password. Please try again.';
    }
}
?>
