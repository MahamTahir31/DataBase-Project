<?php

require_once('TicketPDF.php');
// Include the TicketPDF class

// Database connection details
$host = '127.0.0.1';
$username = 'root';
$password = ''; // Leave it empty for no password
$database = 'travel_blog'; // Replace with your actual database name


// Create a database connection
$link = new mysqli($host, $username, $password, $database);

// Check if the connection was successful
if ($link->connect_error) {
    die('Connection failed: ' . $link->connect_error);
}

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare and execute the SELECT query
    $query = "SELECT * FROM booking WHERE id = $id";
    $result = $link->query($query);

    // Check if the query was successful and fetched at least one row
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Get the booking data from the row
        $bookingData = [
            'username' => $row['username'],
            'card_name' => $row['card_name'],
            'stay_duration' => $row['stay_duration'],
            'travel_date' => $row['travel_date'],
            'ticket_count' => $row['ticket_count'],
            'ticket_price' => $row['ticket_price']
        ];

        // Generate the PDF ticket
        $pdf = new TicketPDF();
        $pdf->generateTicket($bookingData);

        // Output the PDF as a download
        $pdf->Output('ticket.pdf', 'D');
        exit();
    } else {
        echo 'No data found for the provided ID.';
    }
} else {
    echo 'Invalid ID.';
}
